"""KC144 whole-crystal compiler.

The public surface is deliberately small: generate the lattice, apply typed
transformations, crystallize the registry, and audit the result.
"""

from .audit import audit_crystal
from .holonomy import measure_holonomy
from .lattice import generate_edges, generate_seats
from .navigation import bridge_registry, navigation_report
from .population import crystallize
from .query import QueryBundle, compile_query
from .station import build_station_bodies
from .wave import WaveQuery, propagate
from .v4 import compile_mycelium_framework
from .witness import BridgeWitnessPacket, evaluate_bridge_witness

__all__ = [
    "WaveQuery",
    "BridgeWitnessPacket",
    "QueryBundle",
    "audit_crystal",
    "build_station_bodies",
    "bridge_registry",
    "crystallize",
    "compile_mycelium_framework",
    "compile_query",
    "generate_edges",
    "generate_seats",
    "measure_holonomy",
    "navigation_report",
    "propagate",
    "evaluate_bridge_witness",
]
__version__ = "4.0.0"
