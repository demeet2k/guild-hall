from __future__ import annotations

import argparse
import json
from pathlib import Path

from .audit import audit_crystal
from .holonomy import measure_holonomy, replay_ablation
from .navigation import (
    adjacency,
    bridge_registry,
    navigation_relations,
    navigation_report,
    shortest_path,
)
from .population import crystallize, write_crystal
from .station import build_station_bodies
from .systematic import compile_systematic_framework, frontier_ledger
from .transform import (
    br_mirror,
    coactivation_sigma,
    grid_d4_view,
    kc27_transform,
    x16_schedule_rotate,
)
from .wave import WaveQuery, propagate


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="kc144-crystal")
    commands = parser.add_subparsers(dest="command", required=True)

    build = commands.add_parser("build", help="generate the complete registry")
    build.add_argument("--output", default="registry/crystal.json")
    build.add_argument("--atlas")

    audit = commands.add_parser("audit", help="audit a freshly generated crystal")
    audit.add_argument("--output")

    inspect = commands.add_parser("inspect", help="inspect a generated seat")
    inspect.add_argument("gid", type=int)

    rotate = commands.add_parser("rotate", help="apply a typed transformation")
    rotate.add_argument("gid", type=int)
    rotate.add_argument(
        "operation",
        choices=("grid-r90", "x16-next", "br-mirror", "kc27-J", "sigma"),
    )

    body = commands.add_parser("body", help="inspect a complete station body")
    body.add_argument("gid", type=int)

    navigate = commands.add_parser("navigate", help="compile a shortest declared route")
    navigate.add_argument("start", type=int)
    navigate.add_argument("target", type=int)

    commands.add_parser("navigation-audit", help="audit the complete declared graph")
    commands.add_parser("bridges", help="emit the declared inter-band bridge ledger")
    commands.add_parser("holonomy", help="measure the five-route holonomy")
    commands.add_parser("replay-ablation", help="show the non-live replay counterfactual")
    commands.add_parser("frontier", help="emit the systematic open-obligation ledger")

    wave = commands.add_parser("wave", help="run a bounded parallel navigation wave")
    wave.add_argument("--starts", default="6", help="comma-separated GIDs")
    wave.add_argument("--budget", type=int, default=18)
    wave.add_argument("--query-id", default="KC144.V3.CLI.WAVE")

    systematic = commands.add_parser("systematic", help="compile every V3 registry")
    systematic.add_argument("--output", default="registry/v3")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "build":
        document = write_crystal(args.output, args.atlas)
        _json(
            {
                "status": document["status"],
                "digest": document["digest"],
                "output": str(Path(args.output)),
            }
        )
        return 0

    if args.command == "audit":
        report = audit_crystal()
        if args.output:
            Path(args.output).write_text(
                json.dumps(report, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
        _json(report)
        return 0 if report["verdict"] == "PASS" else 1

    if args.command == "inspect":
        crystal = crystallize()
        if not 1 <= args.gid <= 144:
            raise SystemExit("gid must be 1..144")
        _json(crystal["seats"][args.gid - 1])
        return 0

    if args.command == "body":
        if not 1 <= args.gid <= 144:
            raise SystemExit("gid must be 1..144")
        _json(build_station_bodies()[args.gid - 1])
        return 0

    if args.command == "navigate":
        if not (1 <= args.start <= 144 and 1 <= args.target <= 144):
            raise SystemExit("start and target must be 1..144")
        graph = adjacency(navigation_relations())
        path = shortest_path(args.start, args.target, graph)
        _json(
            {
                "source": args.start,
                "target": args.target,
                "path": path,
                "hops": max(0, len(path) - 1),
                "verdict": "FOUND" if path else "UNREACHABLE",
                "standing": "DECLARED_GRAPH_ROUTE_NOT_TRANSPORT_CERTIFICATION",
            }
        )
        return 0

    if args.command == "navigation-audit":
        _json(navigation_report())
        return 0

    if args.command == "bridges":
        _json(bridge_registry())
        return 0

    if args.command == "holonomy":
        _json(measure_holonomy())
        return 0

    if args.command == "replay-ablation":
        _json(replay_ablation())
        return 0

    if args.command == "frontier":
        _json(frontier_ledger())
        return 0

    if args.command == "wave":
        starts = tuple(int(value) for value in args.starts.split(",") if value)
        _json(propagate(WaveQuery(args.query_id, starts, args.budget)))
        return 0

    if args.command == "systematic":
        release = compile_systematic_framework(args.output)
        _json(release)
        return 0 if release["verdict"] == "PASS" else 1

    transforms = {
        "grid-r90": lambda: grid_d4_view(args.gid, "r90"),
        "x16-next": lambda: x16_schedule_rotate(args.gid, 1, 1),
        "br-mirror": lambda: br_mirror(args.gid),
        "kc27-J": lambda: kc27_transform(args.gid, signs=(-1, -1, -1)),
        "sigma": lambda: coactivation_sigma(args.gid),
    }
    _json(transforms[args.operation]().to_dict())
    return 0
