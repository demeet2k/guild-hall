"""KC144 whole-crystal compiler.

The public surface is deliberately small: generate the lattice, apply typed
transformations, crystallize the registry, and audit the result.
"""

from .audit import audit_crystal
from .holonomy import measure_holonomy
from .lattice import generate_edges, generate_seats
from .navigation import bridge_registry, navigation_report
from .population import crystallize
from .station import build_station_bodies
from .wave import WaveQuery, propagate

__all__ = [
    "WaveQuery",
    "audit_crystal",
    "build_station_bodies",
    "bridge_registry",
    "crystallize",
    "generate_edges",
    "generate_seats",
    "measure_holonomy",
    "navigation_report",
    "propagate",
]
__version__ = "3.0.0"
