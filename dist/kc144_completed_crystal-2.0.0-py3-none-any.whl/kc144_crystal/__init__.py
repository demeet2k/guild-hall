"""KC144 whole-crystal compiler.

The public surface is deliberately small: generate the lattice, apply typed
transformations, crystallize the registry, and audit the result.
"""

from .audit import audit_crystal
from .lattice import generate_edges, generate_seats
from .population import crystallize

__all__ = ["audit_crystal", "crystallize", "generate_edges", "generate_seats"]
__version__ = "2.0.0"
