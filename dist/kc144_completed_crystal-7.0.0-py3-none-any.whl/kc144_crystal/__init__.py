"""KC144 whole-crystal compiler.

The public surface is deliberately small: generate the lattice, apply typed
transformations, crystallize the registry, and audit the result.
"""

from .audit import audit_crystal
from .bridge2pc import CommitAuthorization, commit_bridge, prepare_bridge_commit
from .crosswalk import domain_binding_for_subject
from .edge_manifest import freeze_edge_manifest
from .evidence_v7 import (
    AuthorityKey,
    SignedEvidenceEnvelope,
    admit_signed_envelope,
    authority_registry_integrity,
    empty_authority_registry,
    production_evidence_contract,
    seal_authority_registry,
    verify_signed_envelope,
)
from .holonomy import measure_holonomy
from .lattice import generate_edges, generate_seats
from .navigation import bridge_registry, navigation_report
from .population import crystallize
from .query import QueryBundle, compile_query
from .repair import (
    EvidenceAuthority,
    M12EvidencePacket,
    admit_evidence,
    empty_repair_ledger,
    evidence_packet_contract,
    repair_plan,
    verify_repair_ledger,
)
from .station import build_station_bodies
from .session import SessionSpec, cold_reconstruct, compile_session
from .wave import WaveQuery, propagate
from .v4 import compile_mycelium_framework
from .v5 import compile_global_state
from .v6 import compile_repair_framework
from .v7 import compile_production_evidence_kernel
from .witness import BridgeWitnessPacket, evaluate_bridge_witness

__all__ = [
    "WaveQuery",
    "BridgeWitnessPacket",
    "CommitAuthorization",
    "EvidenceAuthority",
    "AuthorityKey",
    "M12EvidencePacket",
    "SignedEvidenceEnvelope",
    "QueryBundle",
    "SessionSpec",
    "audit_crystal",
    "build_station_bodies",
    "bridge_registry",
    "crystallize",
    "compile_mycelium_framework",
    "compile_query",
    "compile_global_state",
    "compile_repair_framework",
    "compile_production_evidence_kernel",
    "compile_session",
    "commit_bridge",
    "cold_reconstruct",
    "generate_edges",
    "generate_seats",
    "measure_holonomy",
    "navigation_report",
    "propagate",
    "evaluate_bridge_witness",
    "evidence_packet_contract",
    "empty_repair_ledger",
    "empty_authority_registry",
    "freeze_edge_manifest",
    "prepare_bridge_commit",
    "admit_evidence",
    "admit_signed_envelope",
    "authority_registry_integrity",
    "domain_binding_for_subject",
    "production_evidence_contract",
    "repair_plan",
    "verify_repair_ledger",
    "seal_authority_registry",
    "verify_signed_envelope",
]
__version__ = "7.0.0"
