"""KC144 whole-crystal compiler.

The public surface is deliberately small: generate the lattice, apply typed
transformations, crystallize the registry, and audit the result.
"""

from .audit import audit_crystal
from .bridge2pc import CommitAuthorization, commit_bridge, prepare_bridge_commit
from .edge_manifest import freeze_edge_manifest
from .holonomy import measure_holonomy
from .lattice import generate_edges, generate_seats
from .navigation import bridge_registry, navigation_report
from .population import crystallize
from .query import QueryBundle, compile_query
from .station import build_station_bodies
from .session import SessionSpec, cold_reconstruct, compile_session
from .wave import WaveQuery, propagate
from .v4 import compile_mycelium_framework
from .v5 import compile_global_state
from .witness import BridgeWitnessPacket, evaluate_bridge_witness

__all__ = [
    "WaveQuery",
    "BridgeWitnessPacket",
    "CommitAuthorization",
    "QueryBundle",
    "SessionSpec",
    "audit_crystal",
    "build_station_bodies",
    "bridge_registry",
    "crystallize",
    "compile_mycelium_framework",
    "compile_query",
    "compile_global_state",
    "compile_session",
    "commit_bridge",
    "cold_reconstruct",
    "generate_edges",
    "generate_seats",
    "measure_holonomy",
    "navigation_report",
    "propagate",
    "evaluate_bridge_witness",
    "freeze_edge_manifest",
    "prepare_bridge_commit",
]
__version__ = "5.0.0"
