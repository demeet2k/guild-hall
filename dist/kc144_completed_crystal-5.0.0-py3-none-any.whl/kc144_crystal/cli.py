from __future__ import annotations

import argparse
import json
from pathlib import Path

from .audit import audit_crystal
from .bridge2pc import CommitAuthorization, commit_bridge, prepare_bridge_commit
from .edge_manifest import freeze_edge_manifest
from .holonomy import measure_holonomy, replay_ablation
from .navigation import (
    adjacency,
    bridge_registry,
    navigation_relations,
    navigation_report,
    shortest_path,
)
from .population import crystallize, write_crystal
from .query import QueryBundle, compile_query, query_contract
from .station import build_station_bodies
from .session import SessionSpec, cold_reconstruct, compile_session
from .systematic import compile_systematic_framework, frontier_ledger
from .transform import (
    br_mirror,
    coactivation_sigma,
    grid_d4_view,
    kc27_transform,
    x16_schedule_rotate,
)
from .wave import WaveQuery, propagate
from .v4 import compile_mycelium_framework
from .v5 import compile_global_state, default_session_spec
from .witness import (
    BridgeWitnessPacket,
    bridge_witness_contract,
    evaluate_bridge_witness,
)


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False))


def _csv(value: str) -> tuple[str, ...]:
    return tuple(item.strip() for item in value.split(",") if item.strip())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="kc144-crystal")
    commands = parser.add_subparsers(dest="command", required=True)

    build = commands.add_parser("build", help="generate the complete registry")
    build.add_argument("--output", default="registry/crystal.json")
    build.add_argument("--atlas")

    audit = commands.add_parser("audit", help="audit a freshly generated crystal")
    audit.add_argument("--output")

    inspect = commands.add_parser("inspect", help="inspect a generated seat")
    inspect.add_argument("gid", type=int)

    rotate = commands.add_parser("rotate", help="apply a typed transformation")
    rotate.add_argument("gid", type=int)
    rotate.add_argument(
        "operation",
        choices=("grid-r90", "x16-next", "br-mirror", "kc27-J", "sigma"),
    )

    body = commands.add_parser("body", help="inspect a complete station body")
    body.add_argument("gid", type=int)

    navigate = commands.add_parser("navigate", help="compile a shortest declared route")
    navigate.add_argument("start", type=int)
    navigate.add_argument("target", type=int)

    commands.add_parser("navigation-audit", help="audit the complete declared graph")
    commands.add_parser("bridges", help="emit the declared inter-band bridge ledger")
    commands.add_parser("holonomy", help="measure the five-route holonomy")
    commands.add_parser("replay-ablation", help="show the non-live replay counterfactual")
    commands.add_parser("frontier", help="emit the systematic open-obligation ledger")

    wave = commands.add_parser("wave", help="run a bounded parallel navigation wave")
    wave.add_argument("--starts", default="6", help="comma-separated GIDs")
    wave.add_argument("--budget", type=int, default=18)
    wave.add_argument("--query-id", default="KC144.V3.CLI.WAVE")

    systematic = commands.add_parser("systematic", help="compile every V3 registry")
    systematic.add_argument("--output", default="registry/v3")

    query = commands.add_parser("query", help="compile an H06 QueryBundle")
    query.add_argument("--file", help="JSON QueryBundle; overrides query flags")
    query.add_argument("--query-id", default="KC144.V4.CLI.QUERY")
    query.add_argument("--goal")
    query.add_argument("--terms", default="")
    query.add_argument("--domains", default="")
    query.add_argument("--operators", default="")
    query.add_argument("--invariants", default="")
    query.add_argument("--boundaries", default="")
    query.add_argument(
        "--evidence-floor",
        default="STRUCTURAL",
        choices=(
            "STRUCTURAL",
            "SOURCE_DECLARED",
            "INDEPENDENT_REPLAY",
            "PROMOTABLE",
        ),
    )
    query.add_argument("--starts", default="6")
    query.add_argument("--budget", type=int, default=18)
    query.add_argument(
        "--return-mode",
        default="RETURN_ARM",
        choices=("NONE", "RETRACE", "TYPED_RETRACE", "RETURN_ARM"),
    )
    query.add_argument("--max-results", type=int, default=12)

    commands.add_parser("query-contract", help="emit the V4 H06 query contract")
    bridge_witness = commands.add_parser(
        "bridge-witness", help="evaluate a beta transport-witness packet"
    )
    bridge_witness.add_argument("packet")
    commands.add_parser(
        "bridge-witness-contract", help="emit the V4 beta witness contract"
    )
    mycelium = commands.add_parser("mycelium", help="compile the complete V4 runtime")
    mycelium.add_argument("--output", default="registry/v4")

    commands.add_parser("edge-manifest", help="freeze the typed V5 edge manifest")
    session = commands.add_parser("session", help="compile a V5 traversal session")
    session.add_argument("--file", help="JSON SessionSpec; defaults to V5 constellation")
    cold = commands.add_parser("cold-reconstruct", help="replay a V5 reentry seed")
    cold.add_argument("seed")
    bridge_prepare = commands.add_parser(
        "bridge-prepare", help="prepare a beta bridge commit"
    )
    bridge_prepare.add_argument("packet")
    bridge_commit = commands.add_parser(
        "bridge-commit", help="evaluate phase two of a beta bridge commit"
    )
    bridge_commit.add_argument("packet")
    bridge_commit.add_argument("preparation")
    bridge_commit.add_argument("authorization")
    bridge_commit.add_argument(
        "--namespace", choices=("PRODUCTION", "TEST"), default="PRODUCTION"
    )
    global_state = commands.add_parser(
        "global-state", help="compile the complete V5 global state"
    )
    global_state.add_argument("--output", default="registry/v5")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "build":
        document = write_crystal(args.output, args.atlas)
        _json(
            {
                "status": document["status"],
                "digest": document["digest"],
                "output": str(Path(args.output)),
            }
        )
        return 0

    if args.command == "audit":
        report = audit_crystal()
        if args.output:
            Path(args.output).write_text(
                json.dumps(report, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
        _json(report)
        return 0 if report["verdict"] == "PASS" else 1

    if args.command == "inspect":
        crystal = crystallize()
        if not 1 <= args.gid <= 144:
            raise SystemExit("gid must be 1..144")
        _json(crystal["seats"][args.gid - 1])
        return 0

    if args.command == "body":
        if not 1 <= args.gid <= 144:
            raise SystemExit("gid must be 1..144")
        _json(build_station_bodies()[args.gid - 1])
        return 0

    if args.command == "navigate":
        if not (1 <= args.start <= 144 and 1 <= args.target <= 144):
            raise SystemExit("start and target must be 1..144")
        graph = adjacency(navigation_relations())
        path = shortest_path(args.start, args.target, graph)
        _json(
            {
                "source": args.start,
                "target": args.target,
                "path": path,
                "hops": max(0, len(path) - 1),
                "verdict": "FOUND" if path else "UNREACHABLE",
                "standing": "DECLARED_GRAPH_ROUTE_NOT_TRANSPORT_CERTIFICATION",
            }
        )
        return 0

    if args.command == "navigation-audit":
        _json(navigation_report())
        return 0

    if args.command == "bridges":
        _json(bridge_registry())
        return 0

    if args.command == "holonomy":
        _json(measure_holonomy())
        return 0

    if args.command == "replay-ablation":
        _json(replay_ablation())
        return 0

    if args.command == "frontier":
        _json(frontier_ledger())
        return 0

    if args.command == "wave":
        starts = tuple(int(value) for value in args.starts.split(",") if value)
        _json(propagate(WaveQuery(args.query_id, starts, args.budget)))
        return 0

    if args.command == "systematic":
        release = compile_systematic_framework(args.output)
        _json(release)
        return 0 if release["verdict"] == "PASS" else 1

    if args.command == "query":
        if args.file:
            query_value = json.loads(Path(args.file).read_text(encoding="utf-8"))
            bundle = QueryBundle.from_dict(query_value)
        else:
            if not args.goal:
                raise SystemExit("--goal is required when --file is not supplied")
            bundle = QueryBundle(
                query_id=args.query_id,
                goal=args.goal,
                terms=_csv(args.terms),
                domains=_csv(args.domains),
                operators=_csv(args.operators),
                invariants=_csv(args.invariants),
                boundaries=_csv(args.boundaries),
                evidence_floor=args.evidence_floor,
                start_coordinates=tuple(
                    int(value) for value in _csv(args.starts)
                ),
                route_budget=args.budget,
                return_mode=args.return_mode,
                max_results=args.max_results,
            )
        report = compile_query(bundle)
        _json(report)
        return 0 if report["status"] == "COMPILED" else 2

    if args.command == "query-contract":
        _json(query_contract())
        return 0

    if args.command == "bridge-witness":
        packet = BridgeWitnessPacket.from_dict(
            json.loads(Path(args.packet).read_text(encoding="utf-8"))
        )
        report = evaluate_bridge_witness(packet)
        _json(report)
        return 0 if report["verdict"] == "CERTIFIED" else 2

    if args.command == "bridge-witness-contract":
        _json(bridge_witness_contract())
        return 0

    if args.command == "mycelium":
        release = compile_mycelium_framework(args.output)
        _json(release)
        return 0 if release["verdict"] == "PASS" else 1

    if args.command == "edge-manifest":
        _json(freeze_edge_manifest())
        return 0

    if args.command == "session":
        spec = (
            SessionSpec.from_dict(
                json.loads(Path(args.file).read_text(encoding="utf-8"))
            )
            if args.file
            else default_session_spec()
        )
        _json(compile_session(spec))
        return 0

    if args.command == "cold-reconstruct":
        report = cold_reconstruct(
            json.loads(Path(args.seed).read_text(encoding="utf-8"))
        )
        _json(report)
        return 0 if report["verdict"] == "PASS" else 1

    if args.command == "bridge-prepare":
        packet = BridgeWitnessPacket.from_dict(
            json.loads(Path(args.packet).read_text(encoding="utf-8"))
        )
        report = prepare_bridge_commit(packet)
        _json(report)
        return 0 if report["status"] == "PREPARED" else 2

    if args.command == "bridge-commit":
        packet = BridgeWitnessPacket.from_dict(
            json.loads(Path(args.packet).read_text(encoding="utf-8"))
        )
        preparation = json.loads(
            Path(args.preparation).read_text(encoding="utf-8")
        )
        authorization = CommitAuthorization(
            **json.loads(Path(args.authorization).read_text(encoding="utf-8"))
        )
        report = commit_bridge(
            preparation,
            packet,
            authorization,
            namespace=args.namespace,
        )
        _json(report)
        return 0 if report["status"] == "COMMITTED" else 2

    if args.command == "global-state":
        release = compile_global_state(args.output)
        _json(release)
        return 0 if release["verdict"] == "PASS" else 1

    transforms = {
        "grid-r90": lambda: grid_d4_view(args.gid, "r90"),
        "x16-next": lambda: x16_schedule_rotate(args.gid, 1, 1),
        "br-mirror": lambda: br_mirror(args.gid),
        "kc27-J": lambda: kc27_transform(args.gid, signs=(-1, -1, -1)),
        "sigma": lambda: coactivation_sigma(args.gid),
    }
    _json(transforms[args.operation]().to_dict())
    return 0
