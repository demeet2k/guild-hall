"""KC144 whole-crystal compiler.

The public surface is deliberately small: generate the lattice, apply typed
transformations, crystallize the registry, and audit the result.
"""

from .audit import audit_crystal
from .bridge2pc import CommitAuthorization, commit_bridge, prepare_bridge_commit
from .campaign_v8 import (
    AuthorityEnrollmentProof,
    authority_enrollment_contract,
    campaign_manifest,
    campaign_state,
    run_to_barrier,
    validate_campaign_envelope,
    verify_authority_enrollment,
)
from .ceremony_v10 import (
    ExternalCheckpointReceipt,
    GovernanceChallenge,
    GovernanceEnrollmentResponse,
    GovernanceRatification,
    activate_governance_society,
    assemble_pending_society,
    create_governance_challenge,
    governance_ceremony_contract,
    governance_ceremony_plan,
    governance_ratification_contract,
    pending_society_integrity,
    verify_enrollment_response,
    verify_governance_ratification,
)
from .crosswalk import domain_binding_for_subject
from .edge_manifest import freeze_edge_manifest
from .evidence_v7 import (
    AuthorityKey,
    SignedEvidenceEnvelope,
    admit_signed_envelope,
    authority_registry_integrity,
    empty_authority_registry,
    production_evidence_contract,
    seal_authority_registry,
    verify_signed_envelope,
)
from .holonomy import measure_holonomy
from .handoff_v9 import (
    AuthorityPinProposal,
    GovernanceApproval,
    GovernanceMember,
    empty_governance_registry,
    governance_registry_integrity,
    handoff_bundle,
    handoff_state,
    pin_authority_from_proposal,
    run_handoff_to_barrier,
    seal_governance_registry,
    source_harvest_contract,
    threshold_governance_contract,
    verify_authority_pin_proposal,
    verify_source_harvest,
)
from .lattice import generate_edges, generate_seats
from .navigation import bridge_registry, navigation_report
from .population import crystallize
from .query import QueryBundle, compile_query
from .repair import (
    EvidenceAuthority,
    M12EvidencePacket,
    admit_evidence,
    empty_repair_ledger,
    evidence_packet_contract,
    repair_plan,
    verify_repair_ledger,
)
from .station import build_station_bodies
from .session import SessionSpec, cold_reconstruct, compile_session
from .wave import WaveQuery, propagate
from .v4 import compile_mycelium_framework
from .v5 import compile_global_state
from .v6 import compile_repair_framework
from .v7 import compile_production_evidence_kernel
from .v8 import compile_parallel_campaign_runtime
from .v9 import compile_external_handoff_runtime
from .v10 import compile_governance_ceremony_runtime
from .witness import BridgeWitnessPacket, evaluate_bridge_witness

__all__ = [
    "WaveQuery",
    "BridgeWitnessPacket",
    "CommitAuthorization",
    "EvidenceAuthority",
    "AuthorityKey",
    "AuthorityEnrollmentProof",
    "AuthorityPinProposal",
    "GovernanceApproval",
    "GovernanceMember",
    "GovernanceChallenge",
    "GovernanceEnrollmentResponse",
    "GovernanceRatification",
    "ExternalCheckpointReceipt",
    "M12EvidencePacket",
    "SignedEvidenceEnvelope",
    "QueryBundle",
    "SessionSpec",
    "audit_crystal",
    "build_station_bodies",
    "bridge_registry",
    "crystallize",
    "compile_mycelium_framework",
    "compile_query",
    "compile_global_state",
    "compile_repair_framework",
    "compile_production_evidence_kernel",
    "compile_parallel_campaign_runtime",
    "compile_external_handoff_runtime",
    "compile_governance_ceremony_runtime",
    "compile_session",
    "commit_bridge",
    "cold_reconstruct",
    "generate_edges",
    "generate_seats",
    "measure_holonomy",
    "navigation_report",
    "propagate",
    "evaluate_bridge_witness",
    "evidence_packet_contract",
    "empty_repair_ledger",
    "empty_authority_registry",
    "empty_governance_registry",
    "freeze_edge_manifest",
    "prepare_bridge_commit",
    "admit_evidence",
    "admit_signed_envelope",
    "activate_governance_society",
    "assemble_pending_society",
    "authority_enrollment_contract",
    "authority_registry_integrity",
    "domain_binding_for_subject",
    "campaign_manifest",
    "campaign_state",
    "create_governance_challenge",
    "governance_registry_integrity",
    "governance_ceremony_contract",
    "governance_ceremony_plan",
    "governance_ratification_contract",
    "pending_society_integrity",
    "handoff_bundle",
    "handoff_state",
    "production_evidence_contract",
    "repair_plan",
    "run_to_barrier",
    "run_handoff_to_barrier",
    "verify_repair_ledger",
    "seal_authority_registry",
    "seal_governance_registry",
    "source_harvest_contract",
    "threshold_governance_contract",
    "verify_signed_envelope",
    "validate_campaign_envelope",
    "verify_authority_enrollment",
    "verify_authority_pin_proposal",
    "verify_source_harvest",
    "verify_enrollment_response",
    "verify_governance_ratification",
    "pin_authority_from_proposal",
]
__version__ = "10.0.0"
